<?php
$conn = new mysqli("localhost", "root", "root", "adelia_uas");

?>