<?php
require '../koneksi.php';
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$result = mysqli_query($conn, "insert into user set
email='$email', mobile='$mobile',password='$password'");
if($result){
echo json_encode([
'status' => true,
'message' => 'Registrasi berhasil'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Registrasi gagal'
]); }
?>