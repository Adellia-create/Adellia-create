<?php
require '../koneksi.php';
$email = $_POST['email'];
$password = $_POST['password'];
$res = mysqli_query($conn, "select * from user");
// $res = mysqli_fetch_array($res, MYSQLI_ASSOC);
$a =0;
$d;
foreach($res as $r){
    if($r['email'] == $email && $r['password'] == $password){
        $a++;
        $d=$r;
    }
    
}
if($a>0){
    echo json_encode([
        'status' => TRUE,
        'message' => 'Login berhasil',
        'data' => $d
        ]);
}else{
    echo json_encode([
        'status' => FALSE,
        'message' => 'Login gagal'
        ]);
}


?>