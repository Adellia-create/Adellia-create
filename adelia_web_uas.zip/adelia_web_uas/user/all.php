<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select * from user"); 
$data =mysqli_fetch_all($data, MYSQLI_ASSOC);
echo json_encode($data);
?>