<?php
require '../koneksi.php';
$id_peminjaman = $_POST['id_peminjaman'];
$tgl = $_POST['tgl'];
$catatan = $_POST['catatan'];
$result = mysqli_query($conn, "insert into pengembalian set
id_peminjaman=$id_peminjaman, tgl='$tgl', catatan='$catatan'");
if($result){
    mysqli_query($conn, "update peminjaman set
    pengembalian = 1 where id=$id_peminjaman");
echo json_encode([
'status' => true,
'message' => 'Pengembalian berhasil'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Pengembalian gagal'
]); }
?>