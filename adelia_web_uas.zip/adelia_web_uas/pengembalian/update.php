<?php
require '../koneksi.php';
$id_peminjaman = $_POST['id_peminjaman'];
$tgl = $_POST['tgl'];
$catatan = $_POST['catatan'];
$id = $_POST['id'];
$result = mysqli_query($conn, "update pengembalian set
id_peminjaman=$id_peminjaman, tgl='$tgl', catatan='$catatan'
where id='$id'"); if($result){
echo json_encode([
'status' => true,
'message' => 'Pengembalian berhasil diupdate'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Pengembalian gagal diupdate']); }
?>