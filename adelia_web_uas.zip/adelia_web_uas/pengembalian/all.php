<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select * from pengembalian where id_user=".$_POST['id_user']); 
$data =mysqli_fetch_all($data, MYSQLI_ASSOC);
echo json_encode($data);
?>