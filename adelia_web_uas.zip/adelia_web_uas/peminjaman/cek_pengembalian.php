<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select *  from pengembalian where id_peminjaman=".$_POST['id']); 
$data =mysqli_fetch_array($data, MYSQLI_ASSOC);
echo json_encode($data);
?>