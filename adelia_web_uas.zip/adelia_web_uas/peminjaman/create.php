<?php
require '../koneksi.php';
$id_buku = $_POST['id_buku'];
$id_user = $_POST['id_user'];
$tgl = $_POST['tgl'];
$catatan = $_POST['catatan'];
$result = mysqli_query($conn, "insert into peminjaman set
id_buku=$id_buku, id_user=$id_user, tgl='$tgl', catatan='$catatan'");
if($result){
mysqli_query($conn, "update buku set status=1
where id=$id_buku"); 

echo json_encode([
'status' => true,
'message' => 'Peminjaman berhasil'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Peminjaman gagal'
]); }
?>