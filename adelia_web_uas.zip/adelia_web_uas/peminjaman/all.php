<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select  buku.*, peminjaman.*, buku.id as id_buku from peminjaman, buku where peminjaman.id_buku = buku.id AND peminjaman.id_user=".$_POST['id_user']); 
$data =mysqli_fetch_all($data, MYSQLI_ASSOC);
echo json_encode($data);
?>