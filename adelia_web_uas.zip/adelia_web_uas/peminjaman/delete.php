<?php
require '../koneksi.php';
$id = $_POST['id'];
$id_buku = $_POST['id_buku'];
$result = mysqli_query($conn, "delete from peminjaman where
id=".$id);
if($result){
    mysqli_query($conn, "update buku set status=0
    where id=$id_buku"); 
    mysqli_query($conn, "delete from pengembalian where
    id_peminjaman=".$id);
echo json_encode([
'status' => true,
'message' => 'Peminjaman terhapus'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Peminjaman gagal terhapus'
]); }
?>