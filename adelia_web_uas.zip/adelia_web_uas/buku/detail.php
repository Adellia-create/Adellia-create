<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select * from buku
where id=".$_GET['id']);
$data = mysqli_fetch_array($data, MYSQLI_ASSOC);
echo json_encode($data);
?>