<?php
require '../koneksi.php';
$id = $_POST['id'];
$result = mysqli_query($conn, "delete from buku where
id=".$id);
if($result){
echo json_encode([
'status' => true,
'message' => 'Buku terhapus'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Buku gagal terhapus'
]); }
?>