<?php
require '../koneksi.php';
$status = $_POST['status'];
$id = $_POST['id'];
$result = mysqli_query($conn, "update buku set status=$status
where id=$id"); if($result){
echo json_encode([
'status' => true,
'message' => 'Buku berhasil diupdate'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Buku gagal diupdate']); }
?>