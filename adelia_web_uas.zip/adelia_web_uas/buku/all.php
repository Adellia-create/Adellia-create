<?php
require '../koneksi.php';
$data = mysqli_query($conn, "select * from buku"); 
$data =mysqli_fetch_all($data, MYSQLI_ASSOC);
echo json_encode($data);
?>