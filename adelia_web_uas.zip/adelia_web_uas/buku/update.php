<?php
require '../koneksi.php';
$kdBuku = $_POST['kdBuku'];
$nmBuku = $_POST['nmBuku'];
$status = $_POST['status'];
$img = $_POST['img'];
$id = $_POST['id'];
$result = mysqli_query($conn, "update buku set
kdBuku='$kdBuku', nmBuku='$nmBuku', status=$status, img='$img'
where id='$id'"); if($result){
echo json_encode([
'status' => true,
'message' => 'Buku berhasil diupdate'
]); }else{
echo json_encode([
'status' => false,
'message' => 'Buku gagal diupdate']); }
?>