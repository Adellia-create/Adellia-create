<?php
require '../koneksi.php';
$kdBuku = $_POST['kdBuku'];
$nmBuku = $_POST['nmBuku'];
$status = $_POST['status'];
$img = $_POST['img'];
$result = mysqli_query($conn, "insert into buku set
kdBuku='$kdBuku', nmBuku='$nmBuku', status=$status, img='$img'");
if($result){
echo json_encode([
'res' => true,
'msg' => 'Buku berhasil diinput'
]); }else{
echo json_encode([
'res' => false,
'msg' => 'Buku gagal diinput'
]); }
?>